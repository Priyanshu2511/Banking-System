package com.demo.controller;
import java.util.List;

import org.hibernate.mapping.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.dto.AccountDto;
import com.demo.mapper.AccountMapper;
import com.demo.service.AccountService;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
	private AccountService as;

	public AccountController(AccountService as) {
		super();
		this.as = as;
	}
	@PostMapping
	public ResponseEntity<AccountDto> addAccount(@RequestBody  AccountDto accountDto){
		return new ResponseEntity<>(as.createAccount(accountDto),HttpStatus.CREATED);
	}
	@GetMapping("/{id}")
	public ResponseEntity<AccountDto> getAccountById(@PathVariable  Long id){
		AccountDto accountDto =as.getAccountById(id);
		return ResponseEntity.ok(accountDto);
	}
	
	@PutMapping("/{id}/deposite")
	public ResponseEntity<AccountDto>deposite( @PathVariable Long id, @RequestBody java.util.Map<String, Double>request ){
		Double amount  = request.get("amount");
		AccountDto accountDto=as.deposite(id, amount);
		return ResponseEntity.ok(accountDto);
		
	}
	@PutMapping("/{id}/withdraw")
	public ResponseEntity<AccountDto>withdraw( @PathVariable Long id, @RequestBody java.util.Map<String, Double>request ){
		Double amount  = request.get("amount");
		AccountDto accountDto = as.withdraw(id, amount);
		return ResponseEntity.ok(accountDto);
		
}
	@GetMapping
	public ResponseEntity<List<AccountDto>> getAllAccounts(){
		List<AccountDto> accounts = as.getAllAccount();
		return ResponseEntity.ok(accounts);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteAccount(@PathVariable Long id){
		as.deleteAccount(id);
		return ResponseEntity.ok("account is delete successfully");
	}
	
}
